import streamlit as st
import pandas as pd
import numpy as np
import re
import os
from typing import List, Dict, Tuple
from datetime import datetime
import json

# File processing libraries
import PyPDF2
from docx import Document
import fitz  # PyMuPDF

# NLP libraries
import spacy
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from sentence_transformers import SentenceTransformer
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize

# Visualization
import plotly.express as px
import plotly.graph_objects as go

# Download required NLTK data
try:
    nltk.data.find('tokenizers/punkt')
    nltk.data.find('corpora/stopwords')
except LookupError:
    nltk.download('punkt')
    nltk.download('stopwords')

# Load spaCy model (install with: python -m spacy download en_core_web_sm)
@st.cache_resource
def load_nlp_models():
    """Load and cache NLP models"""
    try:
        nlp = spacy.load("en_core_web_sm")
    except OSError:
        st.error("spaCy model 'en_core_web_sm' not found. Please install it using: python -m spacy download en_core_web_sm")
        st.stop()
    
    # Load sentence transformer for advanced similarity
    sentence_model = SentenceTransformer('all-MiniLM-L6-v2')
    return nlp, sentence_model

class ResumeParser:
    """Class to handle resume parsing from PDF and DOCX files"""
    
    def __init__(self, nlp_model):
        self.nlp = nlp_model
        self.skills_keywords = [
            'python', 'java', 'javascript', 'react', 'angular', 'vue', 'node', 'express',
            'django', 'flask', 'fastapi', 'sql', 'mysql', 'postgresql', 'mongodb',
            'aws', 'azure', 'gcp', 'docker', 'kubernetes', 'git', 'linux', 'windows',
            'html', 'css', 'bootstrap', 'tailwind', 'machine learning', 'deep learning',
            'tensorflow', 'pytorch', 'scikit-learn', 'pandas', 'numpy', 'matplotlib',
            'data analysis', 'data science', 'artificial intelligence', 'nlp',
            'computer vision', 'opencv', 'selenium', 'testing', 'agile', 'scrum'
        ]
    
    def extract_text_from_pdf(self, pdf_file) -> str:
        """Extract text from PDF file"""
        try:
            # Method 1: PyMuPDF (more reliable)
            doc = fitz.open(stream=pdf_file.read(), filetype="pdf")
            text = ""
            for page in doc:
                text += page.get_text()
            doc.close()
            
            if text.strip():
                return text
            
            # Method 2: PyPDF2 (fallback)
            pdf_file.seek(0)  # Reset file pointer
            reader = PyPDF2.PdfReader(pdf_file)
            text = ""
            for page in reader.pages:
                text += page.extract_text()
            return text
            
        except Exception as e:
            st.error(f"Error reading PDF: {str(e)}")
            return ""
    
    def extract_text_from_docx(self, docx_file) -> str:
        """Extract text from DOCX file"""
        try:
            doc = Document(docx_file)
            text = ""
            for paragraph in doc.paragraphs:
                text += paragraph.text + "\n"
            return text
        except Exception as e:
            st.error(f"Error reading DOCX: {str(e)}")
            return ""
    
    def extract_email(self, text: str) -> str:
        """Extract email address from text"""
        email_pattern = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
        emails = re.findall(email_pattern, text)
        return emails[0] if emails else "Not found"
    
    def extract_phone(self, text: str) -> str:
        """Extract phone number from text"""
        phone_patterns = [
            r'\+?1?[-.\s]?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}',
            r'\+?91[-.\s]?\d{10}',
            r'\d{3}[-.\s]?\d{3}[-.\s]?\d{4}'
        ]
        
        for pattern in phone_patterns:
            phones = re.findall(pattern, text)
            if phones:
                return phones[0]
        return "Not found"
    
    def extract_name(self, text: str) -> str:
        """Extract name using NLP (first person name found)"""
        doc = self.nlp(text[:500])  # Check first 500 characters
        names = []
        for ent in doc.ents:
            if ent.label_ == "PERSON":
                names.append(ent.text)
        
        if names:
            return names[0]
        
        # Fallback: first line often contains name
        lines = text.strip().split('\n')
        if lines:
            first_line = lines[0].strip()
            if len(first_line.split()) <= 4 and first_line.replace(' ', '').isalpha():
                return first_line
        
        return "Not found"
    
    def extract_education(self, text: str) -> List[str]:
        """Extract education information"""
        education_keywords = [
            'bachelor', 'master', 'phd', 'doctorate', 'degree', 'university',
            'college', 'institute', 'education', 'b.tech', 'm.tech', 'bca',
            'mca', 'bba', 'mba', 'b.sc', 'm.sc', 'engineering'
        ]
        
        education_info = []
        lines = text.lower().split('\n')
        
        for line in lines:
            if any(keyword in line for keyword in education_keywords):
                if len(line.strip()) > 10:  # Avoid too short lines
                    education_info.append(line.strip())
        
        return education_info[:3]  # Return top 3 education entries
    
    def extract_skills(self, text: str) -> List[str]:
        """Extract skills from text"""
        text_lower = text.lower()
        found_skills = []
        
        for skill in self.skills_keywords:
            if skill in text_lower:
                found_skills.append(skill.title())
        
        # Also look for skills section
        skills_section = re.search(r'skills?\s*:?\s*(.*?)(?:\n\n|\n[A-Z])', text, re.IGNORECASE | re.DOTALL)
        if skills_section:
            skills_text = skills_section.group(1)
            # Extract additional skills from skills section
            additional_skills = re.findall(r'\b[A-Za-z+#.]{2,}\b', skills_text)
            found_skills.extend([skill for skill in additional_skills if len(skill) > 2])
        
        return list(set(found_skills))[:15]  # Return unique skills, max 15
    
    def extract_experience(self, text: str) -> List[str]:
        """Extract work experience information"""
        experience_keywords = [
            'experience', 'work', 'employment', 'job', 'position',
            'role', 'company', 'organization', 'internship'
        ]
        
        experience_info = []
        lines = text.split('\n')
        
        # Look for experience section
        in_experience_section = False
        for i, line in enumerate(lines):
            line_lower = line.lower()
            
            # Check if we're entering experience section
            if any(keyword in line_lower for keyword in experience_keywords) and len(line.strip()) < 50:
                in_experience_section = True
                continue
            
            # If in experience section, collect relevant lines
            if in_experience_section:
                if line.strip() and not line.strip().lower().startswith(('education', 'skill', 'project')):
                    if len(line.strip()) > 20:  # Meaningful experience lines
                        experience_info.append(line.strip())
                    
                    # Stop if we hit another section
                    if any(section in line.lower() for section in ['education', 'skills', 'projects', 'certifications']):
                        break
            
            # Also look for company names and positions in general text
            if re.search(r'\b(software engineer|developer|analyst|manager|intern)\b', line_lower):
                if len(line.strip()) > 15:
                    experience_info.append(line.strip())
        
        return list(set(experience_info))[:5]  # Return unique experience, max 5
    
    def parse_resume(self, file) -> Dict:
        """Main method to parse resume and extract all information"""
        filename = file.name
        file_extension = filename.split('.')[-1].lower()
        
        # Extract text based on file type
        if file_extension == 'pdf':
            text = self.extract_text_from_pdf(file)
        elif file_extension == 'docx':
            text = self.extract_text_from_docx(file)
        else:
            st.error(f"Unsupported file format: {file_extension}")
            return None
        
        if not text.strip():
            st.error(f"Could not extract text from {filename}")
            return None
        
        # Extract all information
        parsed_data = {
            'filename': filename,
            'name': self.extract_name(text),
            'email': self.extract_email(text),
            'phone': self.extract_phone(text),
            'education': self.extract_education(text),
            'skills': self.extract_skills(text),
            'experience': self.extract_experience(text),
            'raw_text': text
        }
        
        return parsed_data

class ResumeScreener:
    """Class to handle resume screening and matching"""
    
    def __init__(self, sentence_model):
        self.sentence_model = sentence_model
        self.vectorizer = TfidfVectorizer(stop_words='english', max_features=5000)
    
    def preprocess_text(self, text: str) -> str:
        """Preprocess text for better matching"""
        # Convert to lowercase
        text = text.lower()
        # Remove special characters and extra whitespace
        text = re.sub(r'[^a-zA-Z0-9\s]', ' ', text)
        text = re.sub(r'\s+', ' ', text)
        return text.strip()
    
    def calculate_similarity_tfidf(self, resume_text: str, job_description: str) -> float:
        """Calculate similarity using TF-IDF and cosine similarity"""
        # Preprocess texts
        resume_clean = self.preprocess_text(resume_text)
        job_clean = self.preprocess_text(job_description)
        
        # Create TF-IDF vectors
        try:
            tfidf_matrix = self.vectorizer.fit_transform([resume_clean, job_clean])
            similarity = cosine_similarity(tfidf_matrix[0:1], tfidf_matrix[1:2])[0][0]
            return similarity
        except:
            return 0.0
    
    def calculate_similarity_sentence_transformer(self, resume_text: str, job_description: str) -> float:
        """Calculate similarity using Sentence Transformers"""
        try:
            # Get embeddings
            resume_embedding = self.sentence_model.encode([resume_text])
            job_embedding = self.sentence_model.encode([job_description])
            
            # Calculate cosine similarity
            similarity = cosine_similarity(resume_embedding, job_embedding)[0][0]
            return similarity
        except:
            return 0.0
    
    def calculate_skills_match(self, resume_skills: List[str], job_description: str) -> float:
        """Calculate skills matching percentage"""
        if not resume_skills:
            return 0.0
        
        job_text_lower = job_description.lower()
        matched_skills = 0
        
        for skill in resume_skills:
            if skill.lower() in job_text_lower:
                matched_skills += 1
        
        return matched_skills / len(resume_skills) if resume_skills else 0.0
    
    def screen_resumes(self, resumes: List[Dict], job_description: str) -> List[Dict]:
        """Screen all resumes against job description"""
        results = []
        
        for resume in resumes:
            # Calculate different similarity scores
            tfidf_score = self.calculate_similarity_tfidf(resume['raw_text'], job_description)
            transformer_score = self.calculate_similarity_sentence_transformer(resume['raw_text'], job_description)
            skills_score = self.calculate_skills_match(resume['skills'], job_description)
            
            # Combined score (weighted average)
            combined_score = (
                tfidf_score * 0.3 +
                transformer_score * 0.5 +
                skills_score * 0.2
            )
            
            # Convert to percentage
            final_score = combined_score * 100
            
            result = {
                **resume,
                'tfidf_score': round(tfidf_score * 100, 2),
                'transformer_score': round(transformer_score * 100, 2),
                'skills_score': round(skills_score * 100, 2),
                'final_score': round(final_score, 2)
            }
            
            results.append(result)
        
        # Sort by final score (descending)
        results.sort(key=lambda x: x['final_score'], reverse=True)
        
        return results

def main():
    """Main Streamlit application"""
    st.set_page_config(
        page_title="AI-Powered Resume Screening System",
        page_icon="📄",
        layout="wide"
    )
    
    st.title("🤖 AI-Powered Resume Screening System")
    st.markdown("*Intelligent resume screening using advanced NLP techniques*")
    
    # Load NLP models
    with st.spinner("Loading NLP models..."):
        nlp, sentence_model = load_nlp_models()
    
    # Initialize classes
    parser = ResumeParser(nlp)
    screener = ResumeScreener(sentence_model)
    
    # Sidebar for configuration
    st.sidebar.header("⚙️ Configuration")
    
    # File upload section
    st.header("📁 Upload Resumes")
    uploaded_files = st.file_uploader(
        "Choose resume files (PDF or DOCX)",
        type=['pdf', 'docx'],
        accept_multiple_files=True,
        help="Upload multiple resume files for batch processing"
    )
    
    # Job description input
    st.header("📋 Job Description")
    job_description = st.text_area(
        "Enter the job description:",
        height=200,
        placeholder="Paste the job description here. Include required skills, experience, and qualifications...",
        help="The more detailed the job description, the better the matching accuracy"
    )
    
    # Sample job description
    if st.button("📝 Use Sample Job Description"):
        sample_jd = """
        We are looking for a Python Developer to join our team. 
        
        Requirements:
        - Bachelor's degree in Computer Science or related field
        - 2+ years of experience in Python development
        - Strong knowledge of Django or Flask frameworks
        - Experience with SQL databases (PostgreSQL, MySQL)
        - Familiarity with machine learning libraries (scikit-learn, pandas, numpy)
        - Knowledge of web technologies (HTML, CSS, JavaScript)
        - Experience with version control (Git)
        - Understanding of software testing principles
        - Strong problem-solving and analytical skills
        
        Nice to have:
        - Experience with cloud platforms (AWS, Azure)
        - Knowledge of Docker and containerization
        - Familiarity with React or Angular
        - Experience with data analysis and visualization
        """
        st.text_area("Sample Job Description", value=sample_jd, height=200, key="sample_jd")
        job_description = sample_jd
    
    # Process resumes
    if st.button("🚀 Screen Resumes", type="primary"):
        if not uploaded_files:
            st.error("Please upload at least one resume file.")
        elif not job_description.strip():
            st.error("Please provide a job description.")
        else:
            with st.spinner("Processing resumes..."):
                # Parse all resumes
                parsed_resumes = []
                
                for file in uploaded_files:
                    st.info(f"Processing {file.name}...")
                    parsed_resume = parser.parse_resume(file)
                    if parsed_resume:
                        parsed_resumes.append(parsed_resume)
                
                if not parsed_resumes:
                    st.error("No resumes could be processed successfully.")
                    return
                
                # Screen resumes
                st.info("Screening resumes against job description...")
                results = screener.screen_resumes(parsed_resumes, job_description)
                
                # Store results in session state
                st.session_state.screening_results = results
                st.session_state.job_description = job_description
                
                st.success(f"Successfully screened {len(results)} resumes!")
    
    # Display results
    if 'screening_results' in st.session_state:
        results = st.session_state.screening_results
        
        st.header("📊 Screening Results")
        
        # Top 5 candidates
        st.subheader("🏆 Top 5 Matching Candidates")
        
        top_5 = results[:5]
        
        # Create score comparison chart
        fig = px.bar(
            x=[r['name'] for r in top_5],
            y=[r['final_score'] for r in top_5],
            title="Top 5 Candidates - Matching Scores",
            labels={'x': 'Candidate', 'y': 'Matching Score (%)'},
            color=[r['final_score'] for r in top_5],
            color_continuous_scale='viridis'
        )
        fig.update_layout(showlegend=False)
        st.plotly_chart(fig, use_container_width=True)
        
        # Detailed results
        for i, result in enumerate(top_5, 1):
            with st.expander(f"#{i} {result['name']} - {result['final_score']}% Match"):
                col1, col2 = st.columns(2)
                
                with col1:
                    st.write("**Contact Information:**")
                    st.write(f"📧 Email: {result['email']}")
                    st.write(f"📱 Phone: {result['phone']}")
                    
                    st.write("**Scores Breakdown:**")
                    st.write(f"🎯 Final Score: {result['final_score']}%")
                    st.write(f"📊 TF-IDF Score: {result['tfidf_score']}%")
                    st.write(f"🤖 Transformer Score: {result['transformer_score']}%")
                    st.write(f"💡 Skills Match: {result['skills_score']}%")
                
                with col2:
                    st.write("**Skills:**")
                    if result['skills']:
                        skills_text = ", ".join(result['skills'])
                        st.write(skills_text)
                    else:
                        st.write("No specific skills identified")
                    
                    st.write("**Education:**")
                    if result['education']:
                        for edu in result['education']:
                            st.write(f"• {edu}")
                    else:
                        st.write("No education information found")
                
                # Experience
                if result['experience']:
                    st.write("**Experience:**")
                    for exp in result['experience']:
                        st.write(f"• {exp}")
        
        # All results table
        st.subheader("📋 All Candidates Summary")
        
        df = pd.DataFrame([
            {
                'Rank': i + 1,
                'Name': r['name'],
                'Email': r['email'],
                'Phone': r['phone'],
                'Final Score (%)': r['final_score'],
                'Skills Count': len(r['skills']),
                'Filename': r['filename']
            }
            for i, r in enumerate(results)
        ])
        
        st.dataframe(df, use_container_width=True)
        
        # Download results
        if st.button("💾 Download Results as CSV"):
            csv = df.to_csv(index=False)
            st.download_button(
                label="📥 Download CSV",
                data=csv,
                file_name=f"resume_screening_results_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
                mime="text/csv"
            )

if __name__ == "__main__":
    main()