AI-Powered Resume Screening System
🚀 Project Overview
This is an intelligent resume screening system that uses advanced NLP techniques to match resumes against job descriptions. Built with Python, it provides an intuitive web interface using Streamlit.

🎯 Key Features
Multi-format Resume Parsing: Supports PDF and DOCX files
Intelligent Information Extraction: Automatically extracts name, email, phone, education, skills, and experience
Advanced NLP Matching: Uses TF-IDF, Sentence Transformers, and skills matching
Interactive Web Interface: Beautiful Streamlit GUI with charts and visualizations
Ranking System: Shows top 5 candidates with detailed breakdowns
Export Functionality: Download results as CSV for further analysis
🛠️ Technical Architecture
Core Components:
ResumeParser: Handles PDF/DOCX parsing and information extraction
ResumeScreener: Performs NLP-based matching and scoring
Streamlit Frontend: Provides interactive user interface
NLP Techniques Used:
TF-IDF Vectorization: Traditional text similarity matching
Sentence Transformers: Advanced semantic similarity using pre-trained models
Skills Matching: Keyword-based technical skills identification
Named Entity Recognition: Using spaCy for name extraction
📋 Installation & Setup
Prerequisites
Python 3.8 or higher
pip package manager
Step 1: Install Dependencies
bash
pip install -r requirements.txt
Step 2: Download spaCy Language Model
bash
python -m spacy download en_core_web_sm
Step 3: Run the Application
bash
streamlit run resume_screening_app.py
The application will open in your browser at http://localhost:8501

📖 How to Use
1. Upload Resumes
Click on "Choose resume files"
Select multiple PDF or DOCX resume files
The system supports batch processing
2. Enter Job Description
Paste the job description in the text area
Include required skills, experience, and qualifications
Use the "Sample Job Description" for testing
3. Screen Resumes
Click "Screen Resumes" to start processing
The system will parse each resume and calculate matching scores
4. View Results
See top 5 candidates with detailed breakdowns
View score comparisons in interactive charts
Access complete candidate information in expandable sections
Download results as CSV for further analysis
🧪 Testing the System
Option 1: Create Sample Resumes
Create test resume files with the following content:

Sample Resume 1 (save as resume1.pdf):

John Doe
john.doe@email.com
(555) 123-4567

EDUCATION
Bachelor of Science in Computer Science
XYZ University (2019-2023)

SKILLS
Python, Django, SQL, Git, Machine Learning, Pandas, NumPy

EXPERIENCE
Software Developer Intern
ABC Tech Company (Jun 2022 - Aug 2022)
- Developed web applications using Python and Django
- Worked with PostgreSQL databases
- Implemented machine learning models for data analysis
Sample Resume 2 (save as resume2.pdf):

Jane Smith
jane.smith@email.com
+1-555-987-6543

EDUCATION
Master of Science in Data Science
ABC University (2021-2023)

SKILLS
Python, Flask, JavaScript, React, AWS, Docker, scikit-learn

EXPERIENCE
Data Scientist
XYZ Analytics (Jan 2023 - Present)
- Built predictive models using Python and scikit-learn
- Developed web dashboards with Flask and React
- Deployed applications on AWS cloud platform
Option 2: Use Online Resume Generators
Use tools like Canva, Resume.io, or Zety to create realistic sample resumes
Include varied skill sets to test the matching algorithm
🎯 Interview Talking Points
Technical Highlights:
Multi-Modal Text Processing: Handles both PDF and DOCX formats
Advanced NLP Pipeline: Combines multiple similarity techniques
Real-time Processing: Efficient batch processing of multiple resumes
Interactive Visualization: Professional charts using Plotly
Scalable Architecture: Modular design allows easy feature additions
Key Algorithms Explained:
TF-IDF: Measures importance of terms in documents
Cosine Similarity: Calculates angle between document vectors
Sentence Transformers: Uses BERT-based models for semantic understanding
Named Entity Recognition: Identifies persons, organizations, etc.
Performance Optimizations:
Model caching using Streamlit's @st.cache_resource
Efficient text preprocessing
Batch processing capabilities
Memory-efficient file handling
🔧 Troubleshooting
Common Issues:
spaCy Model Not Found
bash
python -m spacy download en_core_web_sm
PDF Reading Issues
The system uses both PyMuPDF and PyPDF2 as fallbacks
Some PDFs may be image-based (OCR not included in this version)
NLTK Data Missing
The app automatically downloads required NLTK data
Manual download: nltk.download('punkt') and nltk.download('stopwords')
Memory Issues with Large Files
Process resumes in smaller batches
Consider file size limits (under 10MB per file recommended)
🚀 Future Enhancements
OCR support for image-based PDFs
Multiple language support
Advanced skill taxonomy matching
Integration with job boards APIs
Machine learning model training on historical data
Resume formatting and quality scoring
📊 Sample Output Explanation
The system provides three types of scores:

TF-IDF Score: Traditional keyword matching (30% weight)
Transformer Score: Semantic similarity using AI (50% weight)
Skills Score: Direct technical skills matching (20% weight)
Final Score: Weighted combination of all scores
Top candidates are ranked by final score, with detailed breakdowns showing why each candidate matched.

🏆 Why This Project Stands Out
Production-Ready Code: Clean, documented, and modular
Advanced NLP: Uses state-of-the-art techniques
User-Friendly Interface: Professional Streamlit GUI
Comprehensive Features: End-to-end screening solution
Scalable Design: Easy to extend and modify
Interview-Ready: Demonstrates multiple technical concepts
This project showcases your understanding of:

Natural Language Processing
Machine Learning
Web Development
File Processing
Data Visualization
Software Architecture
User Interface Design
