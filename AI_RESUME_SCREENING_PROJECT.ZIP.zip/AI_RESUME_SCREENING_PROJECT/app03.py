"""
Sample Resume Generator for Testing
This script creates sample resume files in DOCX format for testing the screening system
"""

from docx import Document
from docx.shared import Inches
import os

def create_sample_resume_1():
    """Create first sample resume - Python Developer"""
    doc = Document()
    
    # Header
    header = doc.add_heading('JOHN SMITH', 0)
    header.alignment = 1  # Center alignment
    
    contact = doc.add_paragraph('john.smith@email.com | (555) 123-4567 | LinkedIn: linkedin.com/in/johnsmith')
    contact.alignment = 1
    
    # Professional Summary
    doc.add_heading('PROFESSIONAL SUMMARY', level=1)
    doc.add_paragraph(
        'Experienced Python Developer with 3+ years in web development and data analysis. '
        'Proficient in Django, Flask, and machine learning frameworks. Strong background in '
        'database management and cloud deployment.'
    )
    
    # Education
    doc.add_heading('EDUCATION', level=1)
    doc.add_paragraph('Bachelor of Science in Computer Science\nState University, 2020\nGPA: 3.8/4.0')
    
    # Technical Skills
    doc.add_heading('TECHNICAL SKILLS', level=1)
    skills = doc.add_paragraph()
    skills.add_run('Programming Languages: ').bold = True
    skills.add_run('Python, JavaScript